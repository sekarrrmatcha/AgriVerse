@extends('layouts.app')

@section('title', 'Beranda — AgriVerse')

@section('breadcrumb')
    AgriVerse &nbsp;/&nbsp; <b>Beranda</b>
@endsection

@section('content')
<div class="hero">
    <div class="hero__eyebrow">Selamat datang kembali</div>
    <h1 class="hero__title">Halo, {{ strtok($user->name ?? 'pengguna', ' ') }} 👋</h1>
    <p class="hero__desc">
        @if($progresPersen >= 100)
            Semua materi dan praktikum sudah Anda selesaikan. Mantap!
        @else
            Progres belajar Anda saat ini {{ $progresPersen }}%. Lanjutkan materi atau praktikum dari program studi Anda di sidebar.
        @endif
    </p>
</div>

<div class="stats-row">
    <div class="stat-card"><div class="stat-card__num">3</div><div class="stat-card__label">Program studi</div></div>
    <div class="stat-card"><div class="stat-card__num">{{ $prodis->sum('materis_count') }}</div><div class="stat-card__label">Pertemuan materi</div></div>
    <div class="stat-card"><div class="stat-card__num">{{ $prodis->sum('praktikums_count') }}</div><div class="stat-card__label">Modul praktikum</div></div>
    <div class="stat-card"><div class="stat-card__num">{{ $progresPersen }}%</div><div class="stat-card__label">Progres Anda</div></div>
</div>

<div class="section-heading">
    <h2>Peta Program Studi</h2>
    <span class="section-heading__note">3 blok · 1 lahan AgriVerse</span>
</div>
<div class="plot-grid">
    @foreach($prodis as $p)
        <div class="plot-card" style="--accent: {{ $p->accent_color }}">
            <div class="plot-card__bar"></div>
            <div class="plot-card__label">{{ $p->plot_label }}</div>
            <div class="plot-card__nama">{{ $p->nama }}</div>
            <div class="plot-card__desc">{{ $p->deskripsi }}</div>
            <div class="plot-card__links">
                <a href="{{ route('materi.index', $p) }}">{{ $p->materis_count }} Materi</a>
                <a href="{{ route('praktikum.index', $p) }}">{{ $p->praktikums_count }} Praktikum</a>
            </div>
        </div>
    @endforeach
</div>
@endsection
