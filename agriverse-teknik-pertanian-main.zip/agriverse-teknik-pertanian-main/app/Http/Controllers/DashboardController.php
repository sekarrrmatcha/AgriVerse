<?php

namespace App\Http\Controllers;

use App\Models\Prodi;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Halaman Beranda setelah user berhasil login.
     */
    public function index(Request $request)
    {
        $user = $request->user();

        $prodis = Prodi::withCount(['materis', 'praktikums'])->get();

        return view('dashboard', [
            'user' => $user,
            'prodis' => $prodis,
            'progresPersen' => $user->progresPersen(),
        ]);
    }
}
