@extends('layouts.app')

@section('title', 'Beranda — AgriVerse')

@section('breadcrumb')
    AgriVerse &nbsp;/&nbsp; <b>Beranda</b>
@endsection

@section('content')
<div class="hero">
    <div class="hero__eyebrow">Selamat datang kembali</div>
    <h1 class="hero__title">Halo, {{ strtok($user->name ?? 'pengguna', ' ') }} 👋</h1>
    <p class="hero__desc">
        @if($progresPersen >= 100)
            Semua materi dan praktikum sudah Anda selesaikan. Mantap!
        @else
            Progres belajar Anda saat ini {{ $progresPersen }}%. Lanjutkan materi atau praktikum dari program studi Anda dengan satu klik.
        @endif
    </p>
</div>

<div class="stats-row">
    <div class="stat-card"><div class="stat-card__num">{{ $prodis->count() }}</div><div class="stat-card__label">Program studi</div></div>
    <div class="stat-card"><div class="stat-card__num">{{ $totalMateri }}</div><div class="stat-card__label">Pertemuan materi</div></div>
    <div class="stat-card"><div class="stat-card__num">{{ $totalPraktikum }}</div><div class="stat-card__label">Modul praktikum</div></div>
    <div class="stat-card"><div class="stat-card__num">{{ $progresPersen }}%</div><div class="stat-card__label">Progres Anda</div></div>
</div>

<div class="dashboard-grid">
    <section class="dashboard-panel">
        <div class="section-heading">
            <h2>Ringkasan belajar</h2>
            <span class="section-heading__note">Aktivitas Anda</span>
        </div>
        <div class="summary-stack">
            <div class="summary-card">
                <div class="summary-card__label">Materi selesai</div>
                <div class="summary-card__value">{{ $completedMateri }} / {{ $totalMateri }}</div>
            </div>
            <div class="summary-card">
                <div class="summary-card__label">Praktikum selesai</div>
                <div class="summary-card__value">{{ $completedPraktikum }} / {{ $totalPraktikum }}</div>
            </div>
            <div class="summary-card summary-card--accent">
                <div class="summary-card__label">Program studi aktif</div>
                <div class="summary-card__value">{{ $activeProdi?->nama ?? 'Belum dipilih' }}</div>
            </div>
        </div>
        <div class="progress-shell" aria-label="progres belajar">
            <div class="progress-shell__bar" style="width: {{ $progresPersen }}%"></div>
        </div>
        <p class="summary-caption">Target belajar Anda saat ini sudah mencapai {{ $progresPersen }}% dari seluruh modul.</p>
    </section>

    <section class="dashboard-panel">
        <div class="section-heading">
            <h2>Lanjutkan sesi belajar</h2>
            <span class="section-heading__note">Langkah berikut</span>
        </div>
        @if($nextMateri || $nextPraktikum)
            @if($nextMateri)
                <a class="next-item" href="{{ route('materi.show', $nextMateri) }}">
                    <span class="next-item__pill">Materi</span>
                    <strong>{{ $nextMateri->judul }}</strong>
                    <span>Pelajari materi berikutnya</span>
                </a>
            @endif
            @if($nextPraktikum)
                <a class="next-item" href="{{ route('praktikum.show', $nextPraktikum) }}">
                    <span class="next-item__pill">Praktikum</span>
                    <strong>{{ $nextPraktikum->judul }}</strong>
                    <span>Kerjakan modul berikutnya</span>
                </a>
            @endif
        @else
            <div class="empty-state">Semua materi dan praktikum sudah selesai. Anda siap untuk review atau mengulang bagian yang ingin diperdalam.</div>
        @endif
    </section>
</div>

<section class="dashboard-panel">
    <div class="section-heading">
        <h2>Aktivitas terbaru</h2>
        <span class="section-heading__note">Riwayat belajar</span>
    </div>
    @if($completedMateriItems->isNotEmpty() || $completedPraktikumItems->isNotEmpty())
        <div class="activity-list">
            @foreach($completedMateriItems as $item)
                @if($item->materi)
                    <div class="activity-item">
                        <span class="activity-item__pill">Materi selesai</span>
                        <strong>{{ $item->materi->judul }}</strong>
                    </div>
                @endif
            @endforeach
            @foreach($completedPraktikumItems as $item)
                @if($item->praktikum)
                    <div class="activity-item">
                        <span class="activity-item__pill">Praktikum selesai</span>
                        <strong>{{ $item->praktikum->judul }}</strong>
                    </div>
                @endif
            @endforeach
        </div>
    @else
        <div class="empty-state">Belum ada aktivitas yang selesai dicatat. Mulai dari materi atau praktikum pertama Anda.</div>
    @endif
</section>

<div class="section-heading">
    <h2>Peta Program Studi</h2>
    <span class="section-heading__note">Blok pembelajaran AgriVerse</span>
</div>
<div class="plot-grid">
    @foreach($prodis as $p)
        <div class="plot-card" style="--accent: {{ $p->accent_color }}">
            <div class="plot-card__bar"></div>
            <div class="plot-card__label">{{ $p->plot_label }}</div>
            <div class="plot-card__nama">{{ $p->nama }}</div>
            <div class="plot-card__desc">{{ $p->deskripsi }}</div>
            <div class="plot-card__links">
                <a href="{{ route('materi.index', $p) }}">{{ $p->materis_count }} Materi</a>
                <a href="{{ route('praktikum.index', $p) }}">{{ $p->praktikums_count }} Praktikum</a>
            </div>
        </div>
    @endforeach
</div>
@endsection
