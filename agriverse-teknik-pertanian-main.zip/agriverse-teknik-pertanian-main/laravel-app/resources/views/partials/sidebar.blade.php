@include('partials.icons')
<aside class="sidebar">
    <div class="brand">
        <div class="brand__mark">{!! $icons['leaf'] !!}</div>
        <div>
            <div class="brand__name">AgriVerse</div>
            <div class="brand__tag">Virtual Learning</div>
        </div>
    </div>

    <div class="sidebar__user">
        <div class="sidebar__user-avatar">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</div>
        <div>
            <div class="sidebar__user-name">{{ auth()->user()->name }}</div>
            @if(auth()->user()->nim)
                <div class="sidebar__user-nim">{{ auth()->user()->nim }}</div>
            @endif
        </div>
    </div>

    <a href="{{ route('dashboard') }}" class="nav-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
        {!! $icons['home'] !!}<span>Beranda</span>
    </a>

    <div class="nav-section-label">Program Studi</div>

    @foreach($prodis ?? \App\Models\Prodi::all() as $p)
        <div class="prodi-block" style="--dot: {{ $p->accent_color }}">
            <div class="prodi-block__head">
                <span class="prodi-block__dot"></span>
                <span class="prodi-block__kode">{{ $p->kode }} · {{ $p->plot_label }}</span>
            </div>
            <div class="prodi-block__links">
                <a href="{{ route('materi.index', $p) }}" class="{{ request()->routeIs('materi.*') && (request()->route('prodi')?->id ?? null) === $p->id ? 'active' : '' }}">
                    {!! $icons['book'] !!} Materi
                </a>
                <a href="{{ route('praktikum.index', $p) }}" class="{{ request()->routeIs('praktikum.*') && (request()->route('prodi')?->id ?? null) === $p->id ? 'active' : '' }}">
                    {!! $icons['flask'] !!} Praktikum
                </a>
            </div>
        </div>
    @endforeach

    <form method="POST" action="{{ route('logout') }}" style="margin-top:auto;">
        @csrf
        <button type="submit" class="sidebar__logout">{!! $icons['logout'] !!} Keluar</button>
    </form>

    <div class="sidebar__foot">D3 TEKNIK INFORMATIKA · PENS<br>PRAKTIKUM DIGITAL 2026</div>
</aside>
