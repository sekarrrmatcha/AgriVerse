@extends('layouts.app')

@section('title', $materi->judul.' — AgriVerse')

@section('breadcrumb')
    AgriVerse &nbsp;/&nbsp; {{ $prodi->kode }} &nbsp;/&nbsp; Materi &nbsp;/&nbsp; <b>Pertemuan 0{{ $materi->pertemuan_ke }}</b>
@endsection

@section('content')
@include('partials.icons')

<a href="{{ route('materi.index', $prodi) }}" class="back-link">{!! $icons['arrowLeft'] !!} Kembali ke daftar materi</a>

<div class="detail-card" style="--accent: {{ $prodi->accent_color }}">
    <div class="detail-card__eyebrow">Pertemuan 0{{ $materi->pertemuan_ke }} · {{ $prodi->nama }}</div>
    <div class="detail-card__title">{{ $materi->judul }}</div>

    <div class="detail-block">
        <h4>Capaian Pembelajaran</h4>
        <ul class="outcome-list">
            @foreach(($materi->capaian ?? []) as $c)
                <li>{{ $c }}</li>
            @endforeach
        </ul>
    </div>

    <div class="detail-block">
        <h4>Pokok Bahasan</h4>
        <ul class="tag-list">
            @foreach(($materi->pokok_bahasan ?? []) as $pb)
                <li>{{ $pb }}</li>
            @endforeach
        </ul>
    </div>

    <form method="POST" action="{{ route('materi.toggle', $materi) }}">
        @csrf
        <button type="submit" class="toggle-btn {{ $selesai ? 'done' : '' }}">
            {!! $icons['check'] !!}
            <span>{{ $selesai ? 'Selesai dipelajari' : 'Tandai selesai' }}</span>
        </button>
    </form>
</div>
@endsection
