@extends('layouts.app')

@section('title', $praktikum->judul.' — AgriVerse')

@section('breadcrumb')
    AgriVerse &nbsp;/&nbsp; {{ $prodi->kode }} &nbsp;/&nbsp; Praktikum &nbsp;/&nbsp; <b>{{ $praktikum->kode }}</b>
@endsection

@section('content')
@include('partials.icons')

<a href="{{ route('praktikum.index', $prodi) }}" class="back-link">{!! $icons['arrowLeft'] !!} Kembali ke daftar praktikum</a>

<div class="detail-card" style="--accent: {{ $prodi->accent_color }}">
    <div class="detail-card__eyebrow">{{ $praktikum->kode }} · {{ $praktikum->tingkat }} · {{ $praktikum->durasi }}</div>
    <div class="detail-card__title">{{ $praktikum->judul }}</div>

    <div class="detail-block">
        <h4>Tujuan</h4>
        <p>{{ $praktikum->tujuan }}</p>
    </div>

    <div class="detail-block">
        <h4>Alat &amp; Bahan Virtual</h4>
        <ul class="tag-list">
            @foreach(($praktikum->alat_bahan ?? []) as $a)
                <li>{{ $a }}</li>
            @endforeach
        </ul>
    </div>

    <div class="detail-block">
        <h4>Langkah Kerja</h4>
        <form method="POST" action="{{ route('praktikum.langkah', $praktikum) }}">
            @csrf
            <ul class="step-list">
                @foreach(($praktikum->langkah ?? []) as $i => $l)
                    @php $isChecked = in_array($i, $langkahSelesai); @endphp
                    <li class="step-item">
                        <label class="step-item__box {{ $isChecked ? 'checked' : '' }}" style="cursor:pointer;">
                            <input type="checkbox" name="langkah_selesai[]" value="{{ $i }}" {{ $isChecked ? 'checked' : '' }} style="position:absolute;opacity:0;width:22px;height:22px;cursor:pointer;">
                            {!! $icons['check'] !!}
                        </label>
                        <span class="step-item__text {{ $isChecked ? 'done' : '' }}">{{ $i + 1 }}. {{ $l }}</span>
                    </li>
                @endforeach
            </ul>
            <button type="submit" class="toggle-btn" style="margin-top:14px;">Simpan Progres Langkah</button>
        </form>
    </div>

    <form method="POST" action="{{ route('praktikum.toggle', $praktikum) }}">
        @csrf
        <button type="submit" class="toggle-btn {{ $selesai ? 'done' : '' }}">
            {!! $icons['check'] !!}
            <span>{{ $selesai ? 'Praktikum selesai' : 'Tandai praktikum selesai' }}</span>
        </button>
    </form>

    @if($praktikum->kuis)
        <div class="detail-block" style="margin-top:28px;">
            <h4>Uji Pemahaman</h4>
            <div class="quiz-box" id="quizBox">
                <div class="quiz-box__q">{{ $praktikum->kuis['pertanyaan'] }}</div>
                <div id="quizOptions"></div>
                <button type="button" id="quizSubmit" class="toggle-btn" disabled>Periksa Jawaban</button>
                <div id="quizFeedback"></div>
            </div>
        </div>

        <script id="quizData" type="application/json">{!! json_encode($praktikum->kuis, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) !!}</script>
        <script>
        (function () {
            const kuis = JSON.parse(document.getElementById('quizData').textContent);
            const optWrap = document.getElementById('quizOptions');
            const submitBtn = document.getElementById('quizSubmit');
            const feedback = document.getElementById('quizFeedback');
            let selected = null;
            let submitted = false;

            function render() {
                optWrap.innerHTML = '';
                kuis.opsi.forEach((op, i) => {
                    const b = document.createElement('button');
                    b.type = 'button';
                    b.textContent = op;
                    b.className = 'quiz-opt-static';
                    b.style.cssText = 'text-align:left;cursor:pointer;';
                    if (submitted && i === kuis.jawaban) b.classList.add('correct');
                    if (!submitted && i === selected) b.style.borderColor = 'var(--accent)';
                    b.disabled = submitted;
                    b.onclick = () => { selected = i; submitBtn.disabled = false; render(); };
                    optWrap.appendChild(b);
                });
            }

            submitBtn.addEventListener('click', () => {
                if (selected === null) return;
                submitted = true;
                const ok = selected === kuis.jawaban;
                feedback.innerHTML = '<div class="quiz-answer">' + (ok ? 'Benar! ' : 'Belum tepat. ') + kuis.penjelasan + '</div>';
                render();
            });

            render();
        })();
        </script>
    @endif
</div>
@endsection
