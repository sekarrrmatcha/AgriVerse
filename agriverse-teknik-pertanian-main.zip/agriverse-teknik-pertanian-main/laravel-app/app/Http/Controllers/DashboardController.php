<?php

namespace App\Http\Controllers;

use App\Models\Materi;
use App\Models\Praktikum;
use App\Models\Prodi;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Halaman Beranda setelah user berhasil login.
     */
    public function index(Request $request)
    {
        $user = $request->user();

        $prodis = Prodi::withCount(['materis', 'praktikums'])->get();

        $completedMateriProgresses = $user->materiProgresses()
            ->whereNotNull('selesai_at')
            ->with('materi')
            ->latest('selesai_at')
            ->get();

        $completedMateriIds = $completedMateriProgresses->pluck('materi_id')->all();

        $completedPraktikumProgresses = $user->praktikumProgresses()
            ->whereNotNull('selesai_at')
            ->with('praktikum')
            ->latest('selesai_at')
            ->get();

        $completedPraktikumIds = $completedPraktikumProgresses->pluck('praktikum_id')->all();

        $nextMateriQuery = Materi::query();
        if ($user->prodi_id) {
            $nextMateriQuery->where('prodi_id', $user->prodi_id);
        }
        if (! empty($completedMateriIds)) {
            $nextMateriQuery->whereNotIn('id', $completedMateriIds);
        }
        $nextMateri = $nextMateriQuery->orderBy('pertemuan_ke')->first();

        $nextPraktikumQuery = Praktikum::query();
        if ($user->prodi_id) {
            $nextPraktikumQuery->where('prodi_id', $user->prodi_id);
        }
        if (! empty($completedPraktikumIds)) {
            $nextPraktikumQuery->whereNotIn('id', $completedPraktikumIds);
        }
        $nextPraktikum = $nextPraktikumQuery->orderBy('id')->first();

        return view('dashboard', [
            'user' => $user,
            'prodis' => $prodis,
            'progresPersen' => $user->progresPersen(),
            'completedMateri' => count($completedMateriIds),
            'completedPraktikum' => count($completedPraktikumIds),
            'completedMateriItems' => $completedMateriProgresses,
            'completedPraktikumItems' => $completedPraktikumProgresses,
            'totalMateri' => $prodis->sum('materis_count'),
            'totalPraktikum' => $prodis->sum('praktikums_count'),
            'activeProdi' => $user->prodi,
            'nextMateri' => $nextMateri,
            'nextPraktikum' => $nextPraktikum,
        ]);
    }
}
