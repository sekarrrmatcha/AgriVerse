#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

START_PORT="${PORT:-8000}"
PORT="$START_PORT"

find_available_port() {
  local candidate="$1"
  while :; do
    if command -v lsof >/dev/null 2>&1; then
      if ! lsof -iTCP:"$candidate" -sTCP:LISTEN >/dev/null 2>&1; then
        echo "$candidate"
        return 0
      fi
    else
      if ! (netstat -an 2>/dev/null | grep -q "LISTEN" | grep ":$candidate " >/dev/null 2>&1); then
        echo "$candidate"
        return 0
      fi
    fi
    candidate=$((candidate + 1))
  done
}

PORT="$(find_available_port "$START_PORT")"
echo "Starting Laravel on http://127.0.0.1:$PORT"
php artisan serve --host=127.0.0.1 --port="$PORT"
