<?php

namespace Tests\Feature;

use App\Models\Materi;
use App\Models\MateriProgress;
use App\Models\Praktikum;
use App\Models\Prodi;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class DashboardTest extends TestCase
{
    use RefreshDatabase;

    public function test_dashboard_shows_learning_summary_and_next_actions_for_authenticated_user(): void
    {
        $prodi = Prodi::create([
            'kode' => 'THP',
            'nama' => 'Teknologi Hasil Pertanian',
            'slug' => 'thp',
            'plot_label' => 'A1',
            'accent_color' => '#7d9c5e',
            'deskripsi' => 'Program studi demo',
        ]);

        $materi = Materi::create([
            'prodi_id' => $prodi->id,
            'pertemuan_ke' => 1,
            'judul' => 'Pengenalan AgriVerse',
            'slug' => 'pengenalan-agriverse',
            'capaian' => ['Memahami dasar'],
            'pokok_bahasan' => ['Dasar'],
        ]);

        $praktikum = Praktikum::create([
            'prodi_id' => $prodi->id,
            'kode' => 'PRK-01',
            'judul' => 'Praktikum Dasar',
            'slug' => 'praktikum-dasar',
            'tingkat' => 'Dasar',
            'durasi' => '45 menit',
            'tujuan' => 'Melatih dasar',
            'alat_bahan' => ['Alat'],
            'langkah' => ['Langkah 1'],
            'kuis' => ['Apa itu?'],
        ]);

        $user = User::create([
            'name' => 'Mahasiswa Uji',
            'nim' => '3124521001',
            'prodi_id' => $prodi->id,
            'email' => 'uji@example.com',
            'password' => bcrypt('password123'),
        ]);

        MateriProgress::create([
            'user_id' => $user->id,
            'materi_id' => $materi->id,
            'selesai_at' => now(),
        ]);

        $response = $this->actingAs($user)->get('/dashboard');

        $response->assertOk()
            ->assertSee('Ringkasan belajar')
            ->assertSee('Lanjutkan sesi belajar')
            ->assertSee($materi->judul)
            ->assertSee($praktikum->judul);
    }
}
