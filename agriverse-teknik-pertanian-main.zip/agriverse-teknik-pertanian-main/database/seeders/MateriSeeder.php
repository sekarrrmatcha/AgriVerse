<?php

namespace Database\Seeders;

use App\Models\Materi;
use App\Models\Prodi;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class MateriSeeder extends Seeder
{
    public function run(): void
    {
        $byProdi = [
            'THP' => [
                ['judul' => 'Kimia dan Komposisi Bahan Pangan',
                    'capaian' => ['Memahami komponen kimia utama bahan pangan: air, karbohidrat, protein, dan lemak.', 'Mampu menghubungkan komposisi kimia dengan mutu produk.'],
                    'pokok' => ['Kadar air dan kadar abu', 'Analisis proksimat', 'Standar mutu SNI bahan pangan', 'Sifat fungsional komponen pangan']],
                ['judul' => 'Mikrobiologi Pangan Dasar',
                    'capaian' => ['Mengenal kelompok mikroorganisme yang berperan pada pangan.', 'Memahami faktor yang memengaruhi pertumbuhan mikroba.'],
                    'pokok' => ['Bakteri, kapang, dan khamir', 'Faktor pertumbuhan mikroba', 'Kontaminasi dan pembusukan pangan', 'Prinsip pengendalian mikroba']],
                ['judul' => 'Teknologi Pengolahan Pangan',
                    'capaian' => ['Memahami prinsip pengolahan pangan termal dan non-termal.', 'Mampu memilih metode pengolahan sesuai jenis bahan.'],
                    'pokok' => ['Pengeringan dan pemanasan', 'Pasteurisasi dan sterilisasi', 'Fermentasi sebagai metode pengolahan', 'Prinsip dasar pengemasan']],
                ['judul' => 'Fermentasi dan Bioproses Pangan',
                    'capaian' => ['Memahami mekanisme fermentasi pangan tradisional dan industrial.', 'Mengenal peran starter culture dalam bioproses.'],
                    'pokok' => ['Fermentasi tempe dan tape', 'Fermentasi susu (yoghurt)', 'Starter culture dan kultur murni', 'Parameter keberhasilan fermentasi']],
                ['judul' => 'Keamanan Pangan dan Sanitasi',
                    'capaian' => ['Menerapkan prinsip HACCP pada proses produksi pangan.', 'Memahami regulasi keamanan pangan di Indonesia.'],
                    'pokok' => ['Titik kritis kendali (CCP)', 'Good Manufacturing Practice (GMP)', 'Sanitasi industri pangan', 'Regulasi dan standar BPOM']],
            ],
            'TPB' => [
                ['judul' => 'Mekanisasi dan Alat Mesin Pertanian',
                    'capaian' => ['Mengenal jenis dan fungsi alat mesin pertanian (alsintan).', 'Memahami prinsip kerja alat olah tanah dan alat panen.'],
                    'pokok' => ['Traktor roda dua dan roda empat', 'Alat pengolahan tanah', 'Alat tanam dan pemupuk', 'Alat dan mesin panen']],
                ['judul' => 'Teknik Irigasi dan Drainase',
                    'capaian' => ['Memahami sistem penyediaan dan pembuangan air pada lahan pertanian.', 'Mampu membandingkan jenis-jenis sistem irigasi.'],
                    'pokok' => ['Irigasi permukaan', 'Irigasi tetes dan sprinkler', 'Perhitungan kebutuhan air tanaman', 'Sistem drainase lahan']],
                ['judul' => 'Instrumentasi dan Kontrol Otomatis',
                    'capaian' => ['Memahami peran sensor dan sistem kendali pada pertanian presisi.', 'Mengenal konsep dasar IoT untuk pertanian.'],
                    'pokok' => ['Sensor kelembaban dan suhu', 'Mikrokontroler dan aktuator', 'Logika kontrol otomatis', 'Sistem IoT pertanian']],
                ['judul' => 'Energi Terbarukan untuk Pertanian',
                    'capaian' => ['Memahami pemanfaatan energi surya dan biomassa di bidang pertanian.'],
                    'pokok' => ['Panel surya untuk pompa air', 'Biogas dari limbah pertanian', 'Efisiensi energi pada alsintan']],
                ['judul' => 'Teknik Tanah dan Konservasi Air',
                    'capaian' => ['Memahami sifat fisik tanah dan pengelolaan air lahan.', 'Mampu menjelaskan prinsip konservasi lahan miring.'],
                    'pokok' => ['Struktur dan tekstur tanah', 'Erosi dan faktor penyebabnya', 'Konservasi lahan miring', 'Neraca air lahan']],
            ],
            'TIP' => [
                ['judul' => 'Pengantar Manajemen Agroindustri',
                    'capaian' => ['Memahami ruang lingkup dan karakteristik agroindustri.', 'Mengenal tantangan utama pengelolaan agroindustri di Indonesia.'],
                    'pokok' => ['Struktur industri berbasis pertanian', 'Rantai nilai agroindustri', 'Karakteristik bahan baku pertanian', 'Tantangan dan peluang agroindustri']],
                ['judul' => 'Perencanaan dan Pengendalian Produksi',
                    'capaian' => ['Mampu menyusun rencana produksi agroindustri sederhana.'],
                    'pokok' => ['Peramalan permintaan', 'Perencanaan kapasitas produksi', 'Penjadwalan produksi', 'Pengendalian persediaan']],
                ['judul' => 'Teknik Tata Cara Kerja',
                    'capaian' => ['Mampu menganalisis efisiensi kerja pada lini produksi.'],
                    'pokok' => ['Studi waktu (time study)', 'Studi gerak (motion study)', 'Peta kerja', 'Penentuan waktu baku']],
                ['judul' => 'Sistem Manajemen Mutu Agroindustri',
                    'capaian' => ['Menerapkan prinsip standar mutu ISO dan HACCP pada agroindustri.'],
                    'pokok' => ['Dokumentasi sistem mutu', 'Audit internal', 'Tindakan korektif dan pencegahan', 'Sertifikasi mutu produk']],
                ['judul' => 'Manajemen Rantai Pasok dan Limbah Agroindustri',
                    'capaian' => ['Memahami aliran bahan baku hingga produk jadi serta pengelolaan limbahnya.'],
                    'pokok' => ['Logistik hulu-hilir', 'Pengolahan limbah agroindustri', 'Prinsip ekonomi sirkular', 'Efisiensi rantai pasok']],
            ],
        ];

        foreach ($byProdi as $kode => $items) {
            $prodi = Prodi::where('kode', $kode)->firstOrFail();

            foreach ($items as $i => $item) {
                Materi::updateOrCreate(
                    ['slug' => Str::slug($kode.'-'.$item['judul'])],
                    [
                        'prodi_id' => $prodi->id,
                        'pertemuan_ke' => $i + 1,
                        'judul' => $item['judul'],
                        'capaian' => $item['capaian'],
                        'pokok_bahasan' => $item['pokok'],
                    ]
                );
            }
        }
    }
}
